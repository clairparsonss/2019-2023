
public class LoopPractice1 {

	public LoopPractice1() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args)
	{
		
	
				int num2 = 1;
				int num1 = 1;
				
				while (num1 <=5)
		{
			//System.out.println(num1);
			num1++;
		}
				
				//For loop that counts to 5
				
				for(int i = 1; i <= 5; i++ )
				{
					//System.out.println(i);
				}
				
				//Do loop that counts to 5
				
				do
				{
					System.out.println(num2);
					num2++;
				}
				while(num2 <=5);
				
				//For loop that counts backwards
				for(int j = 5; j >= 1; j-- )
				{
					System.out.println(j);
				}
				
				System.out.println("Blast off!");
				
				for(char k = 'a'; k <= 'z'; k++)
				{
					System.out.print(k);
				}
		



	}

}
