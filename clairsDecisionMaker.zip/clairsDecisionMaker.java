import java.util.Random;
import java.util.Scanner;

public class clairsDecisionMaker {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		
		
		
		
		System.out.println("Welcome to my magical decision maker, made for indecisive airheads like you");

		System.out.println("What do you need help deciding? > ");
		scan.nextLine();

		System.out.println("Alright, we are almost done here? \nHow many options do you have? (TWO MIN, FIVE MAX) >");
		String numOptions = scan.nextLine();

		if (numOptions.contains("2")) {

			System.out.println("Please type your first option >");
			String option1 = scan.nextLine();

			System.out.println("Please type your second option >");
			String option2 = scan.nextLine();

			Random generator = new Random();
			int last = generator.nextInt(2) + 1;

			if (last == 1) {
				System.out.println("The final decision is " + option1);
			} else if (last == 2) {
				System.out.println("The final decision is " + option2);
			}

		}

		else if (numOptions.contains("3")) {
			System.out.println("Please type your first option >");
			String option1 = scan.nextLine();

			System.out.println("Please type your second option >");
			String option2 = scan.nextLine();

			System.out.println("Please type your third option >");
			String option3 = scan.nextLine();

			Random generator = new Random();
			int last = generator.nextInt(3) + 1;

			if (last == 1) {
				System.out.println("The final decision is " + option1);
			} else if (last == 2) {
				System.out.println("The final decision is " + option2);
			}

			else if (last == 3) {
				System.out.println("The final decision is " + option3);
			}
		}

		else if (numOptions.contains("4")) {
			System.out.println("Please type your first option >");
			String option1 = scan.nextLine();

			System.out.println("Please type your second option >");
			String option2 = scan.nextLine();

			System.out.println("Please type your third option >");
			String option3 = scan.nextLine();

			System.out.println("Please type your fourth option >");
			String option4 = scan.nextLine();

			Random generator = new Random();
			int last = generator.nextInt(4) + 1;

			if (last == 1) {
				System.out.println("The final decision is " + option1);
			} else if (last == 2) {
				System.out.println("The final decision is " + option2);
			}

			else if (last == 3) {
				System.out.println("The final decision is " + option3);
			}

			else if (last == 4) {
				System.out.println("The final decision is " + option4);
			}
		}

		else if (numOptions.contains("4")) {
			System.out.println("Please type your first option >");
			String option1 = scan.nextLine();

			System.out.println("Please type your second option >");
			String option2 = scan.nextLine();

			System.out.println("Please type your third option >");
			String option3 = scan.nextLine();

			System.out.println("Please type your fourth option >");
			String option4 = scan.nextLine();

			Random generator = new Random();
			int last = generator.nextInt(4) + 1;

			if (last == 1) {
				System.out.println("The final decision is " + option1);
			} else if (last == 2) {
				System.out.println("The final decision is " + option2);
			}

			else if (last == 3) {
				System.out.println("The final decision is " + option3);
			}

			else if (last == 4) {
				System.out.println("The final decision is " + option4);
			}
		}

		else if (numOptions.contains("5")) {
			System.out.println("Please type your first option >");
			String option1 = scan.nextLine();

			System.out.println("Please type your second option >");
			String option2 = scan.nextLine();

			System.out.println("Please type your third option >");
			String option3 = scan.nextLine();

			System.out.println("Please type your fourth option >");
			String option4 = scan.nextLine();

			System.out.println("Please type your fifth option >");
			String option5 = scan.nextLine();

			Random generator = new Random();
			int last = generator.nextInt(5) + 1;

			if (last == 1) {
				System.out.println("The final decision is " + option1);
			} else if (last == 2) {
				System.out.println("The final decision is " + option2);
			}

			else if (last == 3) {
				System.out.println("The final decision is " + option3);
			}

			else if (last == 4) {
				System.out.println("The final decision is " + option4);
			}

			else if (last == 5) {
				System.out.println("The final decision is " + option5);
			}
		}
		
		

	}

}
