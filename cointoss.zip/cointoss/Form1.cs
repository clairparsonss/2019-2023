﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Clair Parsons IST 1551 Coin Toss Lab 10
// 12/01/23

namespace coinToss
{
    public partial class Form1 : Form
    {
        Random random = new Random(); // tell c# that random numbers exist

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void headsPictureBox_Click(object sender, EventArgs e)
        {

        }

        private void tailsPictureBox_Click(object sender, EventArgs e)
        {

        }

        private void tossBotton_Click(object sender, EventArgs e)
        {
           
            int rando = random.Next(0, 2); // between 0 and 1 for random number

          
            if (rando == 0) // if 0 then tails
            {
                
                headsPictureBox.Visible = false;
                tailsPictureBox.Visible = true;
            }
            else // if 1 then heads
            {
               
                headsPictureBox.Visible = true;
                tailsPictureBox.Visible = false;
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            
            Application.Exit(); // bye bye
        }
    }
}
