import random

x = "yes"

while x == "yes":
    dice = random.randint(1, 6)
    print(dice)

    x = input("Do you want to roll again? Type yes or no!:")
    print("\n")