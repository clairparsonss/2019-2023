﻿namespace distanceConverter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.enterDistance = new System.Windows.Forms.TextBox();
            this.fromBox = new System.Windows.Forms.GroupBox();
            this.toBox = new System.Windows.Forms.GroupBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.resultLabel = new System.Windows.Forms.Label();
            this.results = new System.Windows.Forms.Label();
            this.convertbutton = new System.Windows.Forms.Button();
            this.exitbutton = new System.Windows.Forms.Button();
            this.fromBox.SuspendLayout();
            this.toBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(168, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(287, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter a distance to convert:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // enterDistance
            // 
            this.enterDistance.Location = new System.Drawing.Point(461, 74);
            this.enterDistance.Name = "enterDistance";
            this.enterDistance.Size = new System.Drawing.Size(100, 20);
            this.enterDistance.TabIndex = 1;
            this.enterDistance.TextChanged += new System.EventHandler(this.enterDistance_TextChanged);
            // 
            // fromBox
            // 
            this.fromBox.BackColor = System.Drawing.Color.MintCream;
            this.fromBox.Controls.Add(this.listBox1);
            this.fromBox.Font = new System.Drawing.Font("Showcard Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fromBox.ForeColor = System.Drawing.Color.MidnightBlue;
            this.fromBox.Location = new System.Drawing.Point(162, 109);
            this.fromBox.Name = "fromBox";
            this.fromBox.Size = new System.Drawing.Size(200, 100);
            this.fromBox.TabIndex = 2;
            this.fromBox.TabStop = false;
            this.fromBox.Text = "From";
            // 
            // toBox
            // 
            this.toBox.BackColor = System.Drawing.Color.MintCream;
            this.toBox.Controls.Add(this.listBox2);
            this.toBox.Font = new System.Drawing.Font("Showcard Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toBox.ForeColor = System.Drawing.Color.MidnightBlue;
            this.toBox.Location = new System.Drawing.Point(378, 109);
            this.toBox.Name = "toBox";
            this.toBox.Size = new System.Drawing.Size(200, 100);
            this.toBox.TabIndex = 3;
            this.toBox.TabStop = false;
            this.toBox.Text = "To";
            this.toBox.Enter += new System.EventHandler(this.toBox_Enter);
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Showcard Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 17;
            this.listBox1.Items.AddRange(new object[] {
            "Inches",
            "Feet",
            "Yards"});
            this.listBox1.Location = new System.Drawing.Point(8, 26);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(184, 55);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // listBox2
            // 
            this.listBox2.Font = new System.Drawing.Font("Showcard Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 17;
            this.listBox2.Items.AddRange(new object[] {
            "Inches",
            "Feet",
            "Yards"});
            this.listBox2.Location = new System.Drawing.Point(10, 26);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(184, 55);
            this.listBox2.TabIndex = 1;
            this.listBox2.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Showcard Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label2.Location = new System.Drawing.Point(289, 231);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Result:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // resultLabel
            // 
            this.resultLabel.AutoSize = true;
            this.resultLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.resultLabel.Location = new System.Drawing.Point(499, 248);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Size = new System.Drawing.Size(0, 13);
            this.resultLabel.TabIndex = 5;
            // 
            // results
            // 
            this.results.AutoSize = true;
            this.results.BackColor = System.Drawing.Color.MintCream;
            this.results.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.results.Location = new System.Drawing.Point(376, 233);
            this.results.MinimumSize = new System.Drawing.Size(100, 20);
            this.results.Name = "results";
            this.results.Size = new System.Drawing.Size(100, 20);
            this.results.TabIndex = 6;
            this.results.Click += new System.EventHandler(this.results_Click);
            // 
            // convertbutton
            // 
            this.convertbutton.BackColor = System.Drawing.Color.MintCream;
            this.convertbutton.Font = new System.Drawing.Font("Showcard Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.convertbutton.ForeColor = System.Drawing.Color.MidnightBlue;
            this.convertbutton.Location = new System.Drawing.Point(287, 273);
            this.convertbutton.Name = "convertbutton";
            this.convertbutton.Size = new System.Drawing.Size(75, 31);
            this.convertbutton.TabIndex = 7;
            this.convertbutton.Text = "Convert";
            this.convertbutton.UseVisualStyleBackColor = false;
            this.convertbutton.Click += new System.EventHandler(this.convertbutton_Click);
            // 
            // exitbutton
            // 
            this.exitbutton.BackColor = System.Drawing.Color.MintCream;
            this.exitbutton.Font = new System.Drawing.Font("Showcard Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitbutton.ForeColor = System.Drawing.Color.MidnightBlue;
            this.exitbutton.Location = new System.Drawing.Point(379, 273);
            this.exitbutton.Name = "exitbutton";
            this.exitbutton.Size = new System.Drawing.Size(75, 31);
            this.exitbutton.TabIndex = 8;
            this.exitbutton.Text = "Exit";
            this.exitbutton.UseVisualStyleBackColor = false;
            this.exitbutton.Click += new System.EventHandler(this.exitbutton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.exitbutton);
            this.Controls.Add(this.convertbutton);
            this.Controls.Add(this.results);
            this.Controls.Add(this.resultLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.toBox);
            this.Controls.Add(this.fromBox);
            this.Controls.Add(this.enterDistance);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.fromBox.ResumeLayout(false);
            this.toBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox enterDistance;
        private System.Windows.Forms.GroupBox fromBox;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.GroupBox toBox;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label resultLabel;
        private System.Windows.Forms.Label results;
        private System.Windows.Forms.Button convertbutton;
        private System.Windows.Forms.Button exitbutton;
    }
}

