﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// clair parsons IST 1551, Distance Converter
namespace distanceConverter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void enterDistance_TextChanged(object sender, EventArgs e)
        {

        }

        private void fromBox_Enter(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void toBox_Enter(object sender, EventArgs e)
        {

        }

        private void results_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void convertbutton_Click(object sender, EventArgs e)
        {
            
            if (!double.TryParse(enterDistance.Text, out double distance))
            {
                results.Text = ("Please enter a valid input."); // if it is not in proper format
            }

            
            double result = ConvertDistance(distance, listBox1.SelectedItem.ToString(), listBox2.SelectedItem.ToString()); // Convert
            result.ToString(); // Forcing ToString to it can display in the label
           
            results.Text = (result); // I can't figure out the error here I know it's probably something simple
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            // clear all
            enterDistance.Clear();
            listBox1.ClearSelected();
            listBox2.ClearSelected();
        }

        private double ConvertDistance(double distance, string fromUnit, string toUnit)
        {
           // The math behind it, I did get some help from my step dad
            if (fromUnit == "Inches" && toUnit == "Feet")
                return distance / 12;
            else if (fromUnit == "Feet" && toUnit == "Inches")
                return distance * 12;
            else if (fromUnit == "Yards" && toUnit == "Feet")
                return distance * 3;
            else if (fromUnit == "Feet" && toUnit == "Yards")
                return distance / 3;
            else if (fromUnit == toUnit)
                return distance; 
            return 0;
        }
    }
}
