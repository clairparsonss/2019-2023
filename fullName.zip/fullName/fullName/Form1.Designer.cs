﻿namespace fullName
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstName = new System.Windows.Forms.Label();
            this.lastName = new System.Windows.Forms.Label();
            this.fullName = new System.Windows.Forms.Label();
            this.firstText = new System.Windows.Forms.TextBox();
            this.lastText = new System.Windows.Forms.TextBox();
            this.nameDisplay = new System.Windows.Forms.Label();
            this.fullNameDisplay = new System.Windows.Forms.Label();
            this.showName = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // firstName
            // 
            this.firstName.AutoSize = true;
            this.firstName.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.firstName.Font = new System.Drawing.Font("Snap ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstName.ForeColor = System.Drawing.Color.DarkGreen;
            this.firstName.Location = new System.Drawing.Point(180, 110);
            this.firstName.Name = "firstName";
            this.firstName.Size = new System.Drawing.Size(119, 26);
            this.firstName.TabIndex = 0;
            this.firstName.Text = "First Name:";
            this.firstName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.firstName.UseCompatibleTextRendering = true;
            this.firstName.UseWaitCursor = true;
            this.firstName.Click += new System.EventHandler(this.firstName_Click);
            // 
            // lastName
            // 
            this.lastName.AutoSize = true;
            this.lastName.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.lastName.Font = new System.Drawing.Font("Snap ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastName.ForeColor = System.Drawing.Color.DarkGreen;
            this.lastName.Location = new System.Drawing.Point(186, 136);
            this.lastName.Name = "lastName";
            this.lastName.Size = new System.Drawing.Size(113, 22);
            this.lastName.TabIndex = 1;
            this.lastName.Text = "Last Name:";
            this.lastName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fullName
            // 
            this.fullName.AutoSize = true;
            this.fullName.Font = new System.Drawing.Font("Snap ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fullName.ForeColor = System.Drawing.Color.DarkGreen;
            this.fullName.Location = new System.Drawing.Point(194, 165);
            this.fullName.Name = "fullName";
            this.fullName.Size = new System.Drawing.Size(106, 22);
            this.fullName.TabIndex = 2;
            this.fullName.Text = "Full Name:";
            // 
            // firstText
            // 
            this.firstText.Location = new System.Drawing.Point(307, 116);
            this.firstText.Name = "firstText";
            this.firstText.Size = new System.Drawing.Size(100, 20);
            this.firstText.TabIndex = 3;
            this.firstText.TextChanged += new System.EventHandler(this.firstText_TextChanged);
            // 
            // lastText
            // 
            this.lastText.Location = new System.Drawing.Point(307, 142);
            this.lastText.Name = "lastText";
            this.lastText.Size = new System.Drawing.Size(100, 20);
            this.lastText.TabIndex = 4;
            this.lastText.TextChanged += new System.EventHandler(this.lastText_TextChanged);
            // 
            // nameDisplay
            // 
            this.nameDisplay.AutoSize = true;
            this.nameDisplay.BackColor = System.Drawing.SystemColors.Window;
            this.nameDisplay.Location = new System.Drawing.Point(310, 174);
            this.nameDisplay.Name = "nameDisplay";
            this.nameDisplay.Size = new System.Drawing.Size(0, 13);
            this.nameDisplay.TabIndex = 5;
            this.nameDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fullNameDisplay
            // 
            this.fullNameDisplay.AutoSize = true;
            this.fullNameDisplay.BackColor = System.Drawing.SystemColors.Window;
            this.fullNameDisplay.Location = new System.Drawing.Point(307, 168);
            this.fullNameDisplay.Name = "fullNameDisplay";
            this.fullNameDisplay.Padding = new System.Windows.Forms.Padding(3, 3, 100, 3);
            this.fullNameDisplay.Size = new System.Drawing.Size(103, 19);
            this.fullNameDisplay.TabIndex = 6;
            this.fullNameDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.fullNameDisplay.Click += new System.EventHandler(this.fullNameDisplay_Click);
            // 
            // showName
            // 
            this.showName.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.showName.Font = new System.Drawing.Font("Snap ITC", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showName.ForeColor = System.Drawing.Color.Honeydew;
            this.showName.Location = new System.Drawing.Point(190, 201);
            this.showName.Name = "showName";
            this.showName.Size = new System.Drawing.Size(123, 23);
            this.showName.TabIndex = 7;
            this.showName.Text = "Show Name";
            this.showName.UseVisualStyleBackColor = false;
            this.showName.Click += new System.EventHandler(this.showName_Click);
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.exitButton.Font = new System.Drawing.Font("Snap ITC", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.ForeColor = System.Drawing.Color.Honeydew;
            this.exitButton.Location = new System.Drawing.Point(319, 201);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(123, 23);
            this.exitButton.TabIndex = 8;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.showName);
            this.Controls.Add(this.fullNameDisplay);
            this.Controls.Add(this.nameDisplay);
            this.Controls.Add(this.lastText);
            this.Controls.Add(this.firstText);
            this.Controls.Add(this.fullName);
            this.Controls.Add(this.lastName);
            this.Controls.Add(this.firstName);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label firstName;
        private System.Windows.Forms.Label lastName;
        private System.Windows.Forms.Label fullName;
        private System.Windows.Forms.TextBox firstText;
        private System.Windows.Forms.TextBox lastText;
        public System.Windows.Forms.Label nameDisplay;
        private System.Windows.Forms.Label fullNameDisplay;
        private System.Windows.Forms.Button showName;
        private System.Windows.Forms.Button exitButton;
    }
}

