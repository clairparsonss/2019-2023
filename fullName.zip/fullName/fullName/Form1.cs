﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace fullName
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void firstName_Click(object sender, EventArgs e)
        {

        }

        private void firstText_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void lastText_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void fullNameDisplay_Click(object sender, EventArgs e)
        {
            
        }

        private void showName_Click(object sender, EventArgs e)
        {
            // Display my text box

            string firstName = firstText.Text; // Getting The User's Name
            string lastName = lastText.Text; // Getting The User's Name
            fullNameDisplay.Text = $"{firstName} {lastName}!";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            fullNameDisplay.Text = "";
            firstText.Text = "";
            lastText.Text = "";
        }
    }
}
