﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// Clair Parsons IST1551 Lab 7 Loan Qualification
namespace loanQual
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkQual_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out double annIncome) &&
               int.TryParse(textBox2.Text, out int yrsEmp))
            {
                if (annIncome >= 40000 && yrsEmp >= 2)
                {
                    label1.Text = "Congratulations! You are qualified!";
                }
                else
                {
                    label1.Text = "Sorry, you do not meet the qualifications.";
                }
            }
            else
            {
                MessageBox.Show("Invalid input.");
            }
        }

        private void clear_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            // You can clear other input fields as needed
            label1.Text = string.Empty; // Clear the result label if necessary
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
