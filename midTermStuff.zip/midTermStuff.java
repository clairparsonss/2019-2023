
public class midTermStuff {

	public midTermStuff() {
		
	}
		// TODO Auto-generated constructor stub
		
		public static void main(String[] args)
		{
			
	
			//For loop that counts by 5
			
	//	for (int i = 5; i <=20; i += 5 )
	//	{
		//	System.out.println(i);
		
	//	}
			
	
	
	
	
 //for (int k = 10; k <= 0; k++)
		
	// System.out.println("Nigel");
		
 
			int j = 15;
			while (j < 0)
			{
				System.out.println("Nigel");
				j--;
			}


			int k = 5;
			while (k <= 20)
			{
				System.out.println (k);
				k+=5;
			}
			for (int k1 = 5; k1 <=20; k1 += 5 )
			{
				System.out.println(k1);
				
			}

		
		
		
			
		}
		
		
	}


