﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Parsons, Clair IST 1552 PW Valid

namespace passwordValidation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void passwordTextbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void submit_Click(object sender, EventArgs e)
        {
            string password = passwordTextbox.Text;

            if (IsPasswordValid(password))
            {
                MessageBox.Show("Password is valid!");
            }
            else
            {
                MessageBox.Show("Password does not meet requirements. Please try again.");
            }
        }

        private bool IsPasswordValid(string password)
        {
            // Check password length
            if (password.Length < 8)
            {
                return false;
            }

           
            if (!password.Any(char.IsUpper))
            {
                return false;
            }

           
            if (!password.Any(char.IsLower))
            {
                return false;
            }

            if (!password.Any(char.IsDigit))
            {
                return false;
            }

            // If all conditions are met, the password is valid
            return true;
        }

        private void exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
