﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// IST 1552 Clair Parsons - Sum of Numbers

namespace sumOfNumbers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void numbersInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void totalButton_Click(object sender, EventArgs e)
        {
            
            string enter = numbersInput.Text;

           
            string[] numbers = enter.Split(',');

            int add = 0;

            
            foreach (string number in numbers)
            {
                if (int.TryParse(number, out int num))
                {
                    add += num;
                }
               
            }

           
            displayLabel.Text = add.ToString(); // to string method to display these lucious beautiful sums
        }

        private void displayLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
