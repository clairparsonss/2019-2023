
public class toStringMethodClass {

 /*
  * This is a class and client code
  * with this as the CLASS, this holds all the information for the CLIENT to test.
  * This of it like an iPad
  * The class is the code behind the iPad
  * The client is the screen that basically shows what the class is doing
  */
	
	int studentId;
	String name;
	
	toStringMethodClass(int studentId, String name) {
		this.studentId = studentId;
		this.name = name;
	}
		
	public String toString() {
		return studentId + " " + name;
	}

	}

