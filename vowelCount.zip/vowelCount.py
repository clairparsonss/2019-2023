str1 = input("Please enter a word : ")

vowels = 0
str1.lower()

for i in str1:
    if (i == 'a' or i == 'e' or i == 'i' or i == 'o' or i == 'u'):
        vowels = vowels + 1

print("Your word has", vowels, "vowels in it!")